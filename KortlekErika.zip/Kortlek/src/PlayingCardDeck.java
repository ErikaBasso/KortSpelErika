import java.util.*;

public class PlayingCardDeck {
         static ArrayList<PlayingCard> myCardList;
         static PlayingCard cardFaceUpOnTable;
         static PlayingCard cardFaceDownInHand;
         static int countWin = 0;
         static int countLose = 0;

         PlayingCardGame playingCardGame = new PlayingCardGame();

         //Skapar kortleken
        public static void createDeck() {
            myCardList = new ArrayList();

            for (int suit = Suits.CLUBS; suit <= Suits.SPADES; suit++) {
                for (int rank = 1; rank <= 13; rank++) {
                    myCardList.add(new PlayingCard(suit, rank, false)); //Kortet får värde här. Man kommer använda index siffrorna när man jämför kortet
                }
            }
            shuffle();
        }

        //Blandar om kortleken
         static void shuffle(){
            Collections.shuffle(myCardList);
             System.out.println("**The cards are shuffled**");
        }

        //1 kort på bordet och ett på handen
        public static void takeTopCards(){
            cardFaceUpOnTable = myCardList.get(0); //Lägger kort index 0 i variabeln
            myCardList.get(0).setCardFaceUp(true); //Ändrar på kort index 0 till cardFaceUp = true
            cardFaceDownInHand = myCardList.get(1);

            System.out.println("Card on the table face up: " + cardFaceUpOnTable);
        }

        //Spelaren gissar om kortet på handen är högre eller lägre. Genom att returnera true om det är högre kort och false om det är lägre kort
        private static boolean playerGuessIfCardIsHigherOrLowerOnHand() throws Exception {
            Scanner sc = new Scanner(System.in);
            System.out.println("Do you think your card in hand is HIGHER or LOWER than the card on the table?");
            String playersGuess = sc.nextLine();

            if(playersGuess.equals("higher") || playersGuess.equals("HIGHER") || playersGuess.equals("Higher")  || playersGuess.equals("h") || playersGuess.equals("H") )
                return true;
            else if (playersGuess.equals("lower")  || playersGuess.equals("LOWER") || playersGuess.equals("Lower") || playersGuess.equals("L")  || playersGuess.equals("l"))
                return false;
            else
                throw new Exception("You spelled incorrectly.");
        }

        //Rätt eller fel svar ger poäng/inte poäng
        public static void playerShouldGuessIfHigherOrLower() throws Exception {
            boolean wasGuessCorrect = isGuessCorrect();

            if(wasGuessCorrect){
                countWin++;
                System.out.println("Congratulations! You are a winner! Your guess was correct. The card in your hand was: " + cardFaceDownInHand + ".");
                }
            else{
                countLose++;
                System.out.println("Wrong answer.The card in your hand was: " + cardFaceDownInHand + ". "); }

            System.out.println("You won " + countWin + " times and you lost " + countLose + " times. You have used " + PlayingCardGame.getCardCount() + " cards of 52 cards.");
        }

    //Reglerna om vilka kort som är högre än andra
    private static boolean isGuessCorrect() throws Exception {
        boolean playerThinksCardInHandIsHigher = playerGuessIfCardIsHigherOrLowerOnHand();

        if(cardFaceDownInHand.getRank() > cardFaceUpOnTable.getRank() && playerThinksCardInHandIsHigher) return true;
        else if (cardFaceDownInHand.getRank() < cardFaceUpOnTable.getRank() && playerThinksCardInHandIsHigher) return false;
        else if(cardFaceDownInHand.getRank() > cardFaceUpOnTable.getRank() && !playerThinksCardInHandIsHigher) return false;
        else if (cardFaceDownInHand.getRank() < cardFaceUpOnTable.getRank() && !playerThinksCardInHandIsHigher) return true;
        else if (cardFaceDownInHand.getRank() == cardFaceUpOnTable.getRank() && cardFaceDownInHand.getSuit() > cardFaceUpOnTable.getSuit() && playerThinksCardInHandIsHigher)
            return true;
        else if (cardFaceDownInHand.getRank() == cardFaceUpOnTable.getRank() && cardFaceDownInHand.getSuit() < cardFaceUpOnTable.getSuit() && playerThinksCardInHandIsHigher)
            return false;
        else if (cardFaceDownInHand.getRank() == cardFaceUpOnTable.getRank() && cardFaceDownInHand.getSuit() > cardFaceUpOnTable.getSuit() && !playerThinksCardInHandIsHigher)
            return false;
        else //(cardInHand.getRank() == cardOnTable.getRank() && cardInHand.getSuit() < cardOnTable.getSuit() && !playerThinksCardInHandIsHigher)
            return true;
    }

        //Här läggs de använda två kortet längst bak i korthögen.
        public static void putCardLast(){
            Collections.rotate(myCardList,-1);
            Collections.rotate(myCardList,-1);
            System.out.println("***The used two cards are on the buttom of the deck now.***");
        }



        //Här hanteras det vad händer om all kort tar slut som vi har spelat med.
        public static void deckEmpty (){

            if (PlayingCardGame.getCardCount()==52){
                System.out.println("Now you have used all the cards in this deck.");
                playerStatisticAfterCardDeckEmpty();
                PlayingCardGame.setCardCount(0); //Efter att man har använt upp alla kort så ska man nolla ut statistiken
                countWin=0;
                countLose=0;
                shuffle();
            }
        }

        //Här ser man om man har vunnit, förlorat eller om det är oavgjort.
        public static void playerStatisticAfterCardDeckEmpty () {

            if(countWin > countLose) {
                System.out.println("You won the whole game");
            }
            else if (countLose > countWin) {
                System.out.println("You lost the whole game");
            }
            else
                System.out.println("You didn´t lose or win, you won as many times a game as you lost");
        }
    }


