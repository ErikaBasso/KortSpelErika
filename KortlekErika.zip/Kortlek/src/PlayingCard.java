
     public class PlayingCard implements Suits{
        private final int mySuit;
        private final int myRank;
        private String myName;
        private boolean isCardFaceUp = false;

        //array för korttypen
        private static final String[] suitStrings = {
                "spades", "hearts", "diamonds", "clubs"
        };


        //array för kortnummer
        //ace (1), jack (11), queen (12), king (13)
        private static final String[] rankStrings = {
                "dummy","ace","two","three","four","five",
                "six","seven","eight","nine","ten",
                "jack","queen","king"
        };

        //en constructur
        public PlayingCard(int suit, int rank, boolean isCardFaceUp){
            mySuit = suit;
            myRank = rank;
            myName = rankStrings[getRank()].toUpperCase()+" of "+
                    suitStrings[getSuit()].toUpperCase();
            isCardFaceUp = isCardFaceUp;
        }
        public int getSuit() {
            return mySuit;
        }

        public int getRank() {
            return myRank;
        }
        public String toString(){
            return myName;
        }

        public boolean isCardFaceUp() {
             return isCardFaceUp;
         }

         public void setCardFaceUp(boolean cardFaceUp) {
             isCardFaceUp = cardFaceUp;
         }

}