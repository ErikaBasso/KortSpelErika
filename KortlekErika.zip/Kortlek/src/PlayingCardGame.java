import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class PlayingCardGame {

    private static PlayingCardDeck playingCardDeck = new PlayingCardDeck();
    private static int cardCount = 2;

    public static int getCardCount() {
        return cardCount;
    }

    public static void setCardCount(int cardCount) {
        PlayingCardGame.cardCount = cardCount;
    }

    public static void main(String[] args) throws Exception {

        ArrayList list = new ArrayList();
        menu();
    }

    // Här nedan metoden för menyn
    public static void menu() throws Exception {
        boolean InGame = true;
        boolean playAgain = true;

        playingCardDeck.createDeck();

        while (InGame) {
            System.out.println("");
            System.out.println("----------------------Menu-------------------------");
            System.out.println("1. Play a game");
            System.out.println("2. Show the game rules");
            System.out.println("3. Quit the game");


            Scanner input = new Scanner(System.in);
            System.out.print("\nChoose from the menu:");
            int choice = 0;
            try {
                choice = input.nextInt();
            }
            catch (InputMismatchException e) {
                System.out.println("You can only choose between 1-3, and only use numbers");
            }

            switch (choice) {
                case 1:

                    playGame();
                    while(playAgain) {
                        cardCount = cardCount +2;
                        System.out.println("1. Play again");
                        System.out.println("2. Go to main menu");
                        choice = input.nextInt();
                        if(choice == 1)
                                playGame();
                        else if (choice == 2)
                                break;
                        else
                            System.out.println("You can only choose between 1 or 2.");
                        }
                    break;
                case 2:
                    showTheRules();
                    break;
                case 3:
                    quitTheGame();
                    return;
                default:
                    System.out.println("Please only choose between 1 to 3");
                    break;
            }
        }
    }

    //Metod för att visa reglerna
    public static void showTheRules() {
        System.out.println("The rules are: We take out two card from the deck. One of them face up and the other one face down. You have to guess if your card is higher och lower compared to " +
                "the card which is face up. If you guess correctly then you win. When you used up all your cards you will know if you won the whole game or not. ");
    }

    //Metod för att gå ur spelet
    public static void quitTheGame() {
        System.out.println("You choosed the end the game.");
    }

    //Metod för att få igång spelet, där anropas flera metoder steg för steg för att följa spelets process.
    public static void playGame()throws Exception {

        playingCardDeck.takeTopCards();
        playingCardDeck.playerShouldGuessIfHigherOrLower();
        playingCardDeck.putCardLast();
        playingCardDeck.deckEmpty();
    }
}







